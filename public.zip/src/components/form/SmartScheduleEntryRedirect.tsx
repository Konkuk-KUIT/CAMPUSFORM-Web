'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

import { useCurrentProjectStore } from '@/store/currentProjectStore';
import { projectService } from '@/services/projectService';

export default function SmartScheduleEntryRedirect() {
  const router = useRouter();
  const projectId = useCurrentProjectStore(s => s.projectId);

  useEffect(() => {
    const toArray = (value: any) => {
      if (Array.isArray(value)) return value;
      if (!value) return [];
      return [value];
    };

    const getRawDays = (data: any) => {
      return (
        data?.days ??
        data?.data?.days ??
        data?.summaries ??
        data?.data?.summaries ??
        data?.interviewSchedules ??
        data?.data?.interviewSchedules ??
        data?.schedules ??
        data?.data?.schedules ??
        data?.slotsByDate ??
        data?.data?.slotsByDate ??
        []
      );
    };

    const hasAssignedSchedule = (data: any) => {
      const rawDays = getRawDays(data);

      if (!Array.isArray(rawDays)) return false;

      return rawDays.some((day: any) => {
        const slots = toArray(
          day?.slots ??
            day?.timeSlots ??
            day?.schedules ??
            day?.interviewSlots ??
            day?.interviews ??
            day?.items,
        );

        return slots.some((slot: any) => {
          const applicants = toArray(
            slot?.applicants ??
              slot?.assignedApplicants ??
              slot?.applicantSummaries ??
              slot?.applicationUsers ??
              slot?.applications ??
              slot?.participants ??
              slot?.applicantList ??
              slot?.applicantInfos ??
              slot?.applicationInfos,
          );

          const interviewers = toArray(
            slot?.interviewers ??
              slot?.assignedInterviewers ??
              slot?.interviewerSummaries ??
              slot?.admins ??
              slot?.adminList ??
              slot?.interviewerList ??
              slot?.interviewerInfos ??
              slot?.adminInfos,
          );

          return applicants.length > 0 || interviewers.length > 0;
        });
      });
    };

    const redirectBySmartScheduleStatus = async () => {
      if (!projectId) return;

      if (typeof window !== 'undefined') {
        const cached = sessionStorage.getItem(`smartScheduleResult:${projectId}`);

        if (cached) {
          router.replace(`/smart-schedule/${projectId}/result`);
          return;
        }
      }

      try {
        const slotData = await projectService.getInterviewSlots(projectId);

        if (hasAssignedSchedule(slotData)) {
          router.replace(`/smart-schedule/${projectId}/result`);
          return;
        }
      } catch (error: any) {
        const status = error?.response?.status;

        if (status !== 404 && status !== 409) {
          console.warn('[SmartScheduleEntry] 확정된 면접 슬롯 조회 실패');
        }
      }

      /**
       * 확정 여부를 판단할 수 있는 API는 현재 interview-slots의 배정 데이터뿐이다.
       * GET smart-schedule은 생성 전 preview API라 미생성 상태에서 409를 만들 수 있으므로,
       * 네비바 진입점에서는 호출하지 않는다.
       */

      try {
        const setting = await projectService.getInterviewSetting(projectId);

        const hasInterviewSetting =
          setting &&
          Array.isArray(setting.interviewDates) &&
          setting.interviewDates.length > 0 &&
          setting.startTime &&
          setting.endTime;

        if (hasInterviewSetting) {
          router.replace(`/smart-schedule/${projectId}/interview-schedule`);
          return;
        }

        router.replace(`/smart-schedule/${projectId}/setting`);
      } catch {
        console.warn('[SmartScheduleEntry] 면접 설정 조회 실패');
        router.replace(`/smart-schedule/${projectId}/setting`);
      }
    };

    redirectBySmartScheduleStatus();
  }, [projectId, router]);

  return (
    <main className="min-h-screen flex items-center justify-center bg-white">
      <p className="text-body-sm text-gray-400">
        스마트 시간표 정보를 불러오는 중입니다.
      </p>
    </main>
  );
}
