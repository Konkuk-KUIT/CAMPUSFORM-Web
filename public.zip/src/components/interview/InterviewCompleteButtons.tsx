'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Button from '@/components/ui/Btn';
import ConfirmModal from '@/components/ConfirmModal';
import { projectService } from '@/services/projectService';
import { toast } from '@/components/Toast';

interface InterviewCompleteButtonsProps {
  projectId: number;
}

export default function InterviewCompleteButtons({ projectId }: InterviewCompleteButtonsProps) {
  const router = useRouter();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleConfirm = async () => {
    try {
      setIsLoading(true);
      await projectService.completeAll(projectId);
      router.push('/home');
    } catch (error) {
      console.error('Failed to complete interview:', error);
      toast.error('면접 종료에 실패했습니다. 다시 시도해주세요.');
    } finally {
      setIsLoading(false);
      setIsModalOpen(false);
    }
  };

  return (
    <>
      {/* 버튼 영역 */}
      <div className="px-4 pb-20 flex flex-col gap-2">
        <Button variant="primary" size="lg" onClick={() => setIsModalOpen(true)} disabled={isLoading}>
          {isLoading ? '처리 중...' : '종료하기'}
        </Button>
      </div>

      <ConfirmModal
        isOpen={isModalOpen}
        onCancel={() => setIsModalOpen(false)}
        onConfirm={handleConfirm}
        description={
          <>
            모든 절차가 종료되며 수정할 수 없습니다.
            <br />
            종료를 확정하시겠습니까?
          </>
        }
      />
    </>
  );
}
