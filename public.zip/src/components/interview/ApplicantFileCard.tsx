'use client';

import Link from 'next/link';
import { useState } from 'react';
import Image from 'next/image';
import StatusDropdown from '@/components/ui/StatusDropdown';
import AppointmentInfoButton from '@/components/ui/AppointmentInfoButton';

interface ApplicantFileCardProps {
  id: number;
  projectId: number;
  name: string;
  info: string;
  initialStatus: '보류' | '합격' | '불합격';
  commentCount?: number;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
  onCommentClick?: () => void;
  appointmentDate?: string;
  appointmentTime?: string;
  onAppointmentClick?: () => void;
  onStatusChange?: (applicantId: number, newStatus: '보류' | '합격' | '불합격') => void;
}

export default function ApplicantFileCard({
  id,
  projectId, 
  name,
  info,
  initialStatus,
  commentCount = 0,
  isFavorite = false,
  onToggleFavorite,
  onCommentClick,
  appointmentDate,
  appointmentTime,
  onAppointmentClick,
  onStatusChange,
}: ApplicantFileCardProps) {
  const [status, setStatus] = useState(initialStatus);

  const handleAppointmentClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onAppointmentClick) {
      onAppointmentClick();
    }
  };

  return (
    <div className="relative w-85.75 h-18.75 bg-white border-b border-gray-100 flex items-center first:border-t">
      <Link 
        href={`/interview/${projectId}/${id}?date=${encodeURIComponent(appointmentDate || '')}&time=${encodeURIComponent(appointmentTime || '')}`}
        className="flex flex-col flex-1"
      >
        <div className="flex items-center gap-2.5">
          <h3 className="text-subtitle-sm-md text-gray-950">{name}</h3>
          {onAppointmentClick && (
            <AppointmentInfoButton date={appointmentDate} time={appointmentTime} onClick={handleAppointmentClick} />
          )}
        </div>
        <p className="mt-1 text-body-rg text-gray-400">{info}</p>
      </Link>

      <div className="flex flex-col items-end gap-2">
        <StatusDropdown value={status} onChange={(newStatus) => {
          setStatus(newStatus);
          onStatusChange?.(id, newStatus);
        }} />

        <div className="flex items-center gap-2.5 text-gray-300">
          <div className="flex items-center gap-1">
            <button className="w-4 h-4 relative" onClick={onCommentClick}>
              <Image src="/icons/comment.svg" alt="댓글" fill />
            </button>
            <span className="text-body-xs-rg text-gray-300">{commentCount}</span>
          </div>
          <button className="w-4.5 h-4.5 relative" onClick={onToggleFavorite}>
            <Image src={isFavorite ? '/icons/star.svg' : '/icons/star-off.svg'} alt="즐겨찾기" fill />
          </button>
        </div>
      </div>
    </div>
  );
}
