import ProjectIdSetter from '@/components/ProjectIdSetter';
import SmartScheduleEntryRedirect from '@/components/form/SmartScheduleEntryRedirect';

export default async function SmartSchedulePage({
  params,
}: {
  params: Promise<{ projectId: string }>;
}) {
  const { projectId } = await params;

  return (
    <>
      <ProjectIdSetter projectId={Number(projectId)} />
      <SmartScheduleEntryRedirect />
    </>
  );
}